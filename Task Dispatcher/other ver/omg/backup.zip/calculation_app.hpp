#pragma once
#include <functional>
#include <future>
#include "thread_pool.hpp"
#include "task_dispather.hpp"

template<class T>
using task = std::function<T()>;

//TODO: thread pool of pack
template<class T>
class calculation_app final
{
public:	
	explicit calculation_app(std::vector<task<T>>& tasks, const std::size_t thread_num) : tasks_{ tasks }, thread_num_{ thread_num } {}

	template<class Strategy>
	void calculate(const logger<Strategy>& log)
	{

		size_t task_counter{ 0 };

		const auto parts = thread_num_;
		auto current_it = tasks_.begin();
		std::size_t cur_part{ 0 };
		
		for (cur_part = 0; cur_part < parts; ++cur_part) {
			const auto part_size = (tasks_.size() * cur_part + tasks_.size()) / parts - (tasks_.size() * cur_part) / parts;
			std::vector<task<T>> part{ current_it, std::next(current_it, part_size) };
			
			if(cur_part == parts - 1) {
				for(auto& task : part) {
					auto [cmd_name, cmd_result] = task();
					final_sum_ += cmd_result;
				}
				break;
			}
			
			auto future = pool_.insert_task([&]
				{
					double current_sum{ 0 };
					for (auto& task : part) {
						auto [cmd_name, cmd_result] = task();
						current_sum += cmd_result;
					}

					return current_sum;
				});
			std::advance(current_it, part_size);

			//final_sum_ += future.get();
			{
				//std::unique_lock <std::mutex> lock{ main_lock };
				final_sum_ += future.get();
			}
		}
		
		//std::vector<task<T>> last_part{ current_it, std::next(current_it, part_size) };
		//for (auto& task : last_part) {
		//	auto [cmd_name, cmd_result] = task();
		//	
		//	{
		//		std::unique_lock <std::mutex> lock{ main_lock };
		//		final_sum_ += cmd_result;
		//	}
		//	//final_sum_ += cmd_result;
		//}
		//
		/*for(auto& task: tasks_) {
			auto future = pool_.insert_task(task);
			auto [cmd_name, cmd_res] = future.get();
			final_sum_ += cmd_res;
		}*/


		pool_.wait_finished();
		//for (auto& task : tasks_) {
		//	if(task_counter == thread_num_) {
		//		auto [cmd, result] = task();
		//		final_sum_ += result;
		//		task_counter = 0;
		//		continue;
		//	}
		//	
		//	auto future = std::async(std::launch::async, task);
		//	//auto [cmd, result] = future.get();
		//	//final_sum_ += result;
		//}
	}
	template<class Strategy>
	void one_thread_calculation(const logger<Strategy>& log)
	{
		final_sum_ = 0;
		for (auto& task : tasks_) {
			auto [cmd_name, cmd_result] = task();
			final_sum_ += cmd_result;
		}
	}

	double result() const {
		return final_sum_;
	}

private:
	std::vector<task<T>>& tasks_;
	//std::atomic<double> final_sum_{ 0 };
	double final_sum_{ 0 };
	std::size_t thread_num_;
	task_dispatcher pool_{ thread_num_ };
	std::mutex main_lock{};
};
