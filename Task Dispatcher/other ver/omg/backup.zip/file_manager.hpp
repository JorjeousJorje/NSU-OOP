#pragma once
#include <filesystem>
#include <fstream>
#include <regex>
#include "task_dispather.hpp"
#include "safe_thread_vector.hpp"
namespace  fs = std::filesystem;


template<typename T>
class task_manager final
{
public:
	task_manager() = delete;
	explicit task_manager(const std::string& path, const std::size_t thread_num) : thread_num_{thread_num } {
		//TODO : empty directory
		for (auto& file : fs::directory_iterator(path)) {
			paths_.emplace_back(file.path());
		}
	}

	template<class Strategy>
	[[nodiscard]] std::vector<task<T>> get_tasks(const logger<Strategy>& log, const std::size_t thread_num) {
		{
			for(auto& path : paths_) {
				pool_.insert_task([&]
				{
					parser_.parse(tasks_, log, path);
				});
			}

			pool_.wait_finished();
		}
		return tasks_.get_std_vector();
	}

	template<class Strategy>
	[[nodiscard]] std::vector<task<T>> get_tasks(const logger<Strategy>& log) {
		
		for (auto& path : paths_) {
			parser_.parse(tasks_, log, path);
		}
		return tasks_.get_std_vector();
	}

	
private:
	class task_parser final
	{
	public:
		task_parser() = default;

		template<class Strategy>
		void parse(safe_thread_vector<T>& tasks, const logger<Strategy>& log, const fs::path& path)
		{
			std::ifstream file_stream{ path };
			std::smatch match{};
			for (std::string line; std::getline(file_stream >> std::ws, line); ) {
				try {
					if (!std::regex_search(line, match, regex_)) {
						throw std::invalid_argument("invalid command: " + line);
					}

					std::istringstream stream{ match.str() };
					std::vector<std::string> cmd_parts{};
					std::string buf{};
					while (!stream.eof()) {
						stream >> buf;
						cmd_parts.emplace_back(buf);
					}
					auto first_num = std::stod(cmd_parts[1]);
					auto second_num = std::stod(cmd_parts[2]);

					if (cmd_parts.front() == "add") {
						tasks.emplace_back([=] { return std::pair{ "add", first_num + second_num }; });
					}
					else if (cmd_parts.front() == "mult") {
						tasks.emplace_back([=] { return std::pair{ "mult", first_num * second_num }; });
					}
					else if (cmd_parts.front() == "add_sq") {
						tasks.emplace_back([=] { return std::pair{ "add_sq", std::pow(first_num, 2) + std::pow(second_num, 2) }; });
					}
					else if (cmd_parts.front() == "sq_add") {
						tasks.emplace_back([=] { return std::pair{ "sq_add", std::pow(first_num + second_num, 2) }; });
					}
					else if (cmd_parts.front() == "sub") {
						tasks.emplace_back([=] { return std::pair{ "sub", first_num - second_num }; });
					}
					else if (cmd_parts.front() == "div") {
						tasks.emplace_back([=] { return std::pair{ "div", first_num / second_num }; });
					}
				}
				catch (const std::invalid_argument& ex) {
					log(log_level::error, __FILE__, __LINE__) << ex.what() << std::endl;
				}
			}
		}

	private:
		const std::regex regex_{ std::string{R"(^\s*?(add|mult|add_sq|sq_add|sub|div){1}(\s[+-]?([0-9]*[.])?[0-9]+){2})" } };
	};


	std::size_t thread_num_;
	task_dispatcher pool_{ thread_num_ };
	
	safe_thread_vector<T> tasks_{};
	std::vector<fs::path> paths_{};

	task_parser parser_;
};