#pragma once
#include <unordered_set>
#include <future>
#include <memory>
#include <random>

#include "worker.hpp"




class task_dispatcher
{
public:
	explicit task_dispatcher(size_t number_of_workers);

	template<class T>
	auto insert_task(T task) -> std::future<decltype(task())>
	{
		auto wrapper = std::make_shared<std::packaged_task<decltype(task())()>>(std::move(task));
		if (!stop_has_started_) {
			std::unique_lock<std::mutex> lock{ main_lock_ };
			tasks_queue_.emplace_back(task_info{ [=] {
				(*wrapper)();
			} });
		}
		schedule();
	
		return wrapper->get_future();
	}
	
	void task_finished(std::size_t worker_id);
	void schedule();
	void wait_finished();
	
	~task_dispatcher();

private:
	
	std::vector<std::unique_ptr<worker>> workers_{};
	std::deque<task_info> tasks_queue_{};
	std::unordered_set<std::size_t> available_workers_{};

	std::mutex main_lock_{};
	std::mutex wait_lock_{};
	std::condition_variable wait_{};

	std::atomic_bool stop_has_started_{ false };
};
