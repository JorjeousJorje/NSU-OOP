#pragma once
#include <condition_variable>
#include <functional>
#include <future>
#include <queue>
#include <thread>
#include <vector>
#include "logger.hpp"

//TODO: don't need queue? Just give array of commands.

class thread_pool final
{
	using task = std::function<void()>;
public:

    explicit thread_pool(const std::size_t thread_num) : available_workers_{thread_num}
    {
        start(thread_num);
    }
	
	~thread_pool() {
        stop();
	}

    template<class T> 
    auto enqueue(T task) -> std::future<decltype(task())>
    {
        auto wrapper = std::make_shared<std::packaged_task<decltype(task())()>>(std::move(task));
        {
            std::lock_guard<std::mutex> lock{ event_lock_ };
            tasks_.emplace([=] {
                (*wrapper)();
            });
        }
        notification_.notify_one();
        return wrapper->get_future();
    }

    void wait_finished()
    {
        std::unique_lock<std::mutex> lock(event_lock_);
        notification_.wait(lock, [&]() { return tasks_.empty() && available_workers_ == threads_.size(); });
    }
	
private:
    std::vector<std::thread> threads_{};
    std::condition_variable notification_{};

	
    std::mutex event_lock_{};
    std::queue<task> tasks_;
    std::size_t available_workers_;
	
    bool thread_stopping_{ false };

    void start(const std::size_t thread_num)
    {
        for (auto i = 0u; i < thread_num; ++i)
        {
            threads_.emplace_back([=] {
                for (;;) {
                    task task;
                    {
                        std::unique_lock<std::mutex> lock{ event_lock_ };
                        notification_.wait(lock, [=] { return thread_stopping_ || !tasks_.empty(); });
                    	
                        if(!tasks_.empty()) {
                            --available_workers_;
                            task = std::move(tasks_.front());
                            tasks_.pop();
                        }
                        else if(thread_stopping_) {
                            break;
                        }
                    }
                	
                    task();
                	
                    std::unique_lock<std::mutex> lock{ event_lock_ };
                    ++available_workers_;
                    notification_.notify_one();
                }
            });
        }
    }

    void stop() noexcept
    {
        {
            std::unique_lock<std::mutex> lock{ event_lock_ };
            thread_stopping_ = true;
            notification_.notify_all();
        }

        for (auto& thread : threads_) {
            thread.join();
        }
    }
};