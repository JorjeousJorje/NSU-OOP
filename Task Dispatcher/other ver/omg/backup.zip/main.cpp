#include <fstream>
#include "logger.hpp"
#include <random>
#include "calculation_app.hpp"
#include "config_parser.hpp"
#include "file_manager.hpp"
#include "execution_timer.hpp"
#include "unordered_map"


template<class T, class dummy = std::enable_if<std::is_floating_point_v<T>>>
struct gen_float
{
	gen_float(const T min, const T max) :dist{ min, max } {}

	const std::uniform_real_distribution<T> dist;
	std::mt19937 engine{ 0 };

	auto operator()() {
		return dist(engine);
	}
};

template<class T, class dummy = std::enable_if<std::is_integral_v<T>>>
struct gen_int
{
	gen_int(const T min, const T max) : dist{ min, max } {}

	const std::uniform_int_distribution<T> dist;
	std::mt19937 engine{ 0 };

	auto operator()() {
		return dist(engine);
	}
};

// TODO: std::pair<std::string, double> - huge type....
int main()
{
	std::ifstream config{ "computation_config.txt" };
	
	const config_parser config_parser{ config };

	auto [main_settings, log_settings] = config_parser.parse();

	task_manager<std::pair<std::string, long double>> task_manager_{ main_settings.at(0), 8};

	logger log{ console_time_log{} };

	timer time3{};
	auto tasks = task_manager_.get_tasks(log, 1);
	log(log_level::warning) << "file time : " << time3.time() << std::endl;
	
	log(log_level::debug, __FILE__, __LINE__) << tasks.size() << std::endl;

	calculation_app<std::pair<std::string, long double>> app{ tasks, 8};

	timer time2{};
	app.calculate(log);
	log(log_level::warning) << "many threads : " << time2.time() << std::endl;

	auto sum1 = app.result();
	log(log_level::warning) << "many threads sum : " << sum1 << std::endl;
	
	timer time{};
	app.one_thread_calculation(log);
	log(log_level::warning) << "one thread : " << time.time() << std::endl;

	
	auto sum2 = app.result();
	log(log_level::warning) << "one threads sum : " << sum2 << std::endl;
	return 0;
	/*std::unordered_map<std::size_t, std::string> commands{ {0, "add"}, {1, "mult"}, {2, "add_sq"}, {3, "sq_add"}, {4, "sub"}, {5, "div"} };
	gen_float generator{ 5., 500. };
	gen_int int_gen{ 0u, 5u };
	for(auto i = 0u; i < 10000; ++i) {
		std::ofstream new_file{ "commands10k/in_" + std::to_string(i) + ".txt" };
		new_file << commands.find(int_gen())->second << ' ' << std::to_string(generator()) << ' ' << std::to_string(generator());
		new_file.close();
	}*/
}