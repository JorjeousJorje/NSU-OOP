#pragma once
#include <string>
#include <unordered_map>
#include <istream>

using logging_config_t = std::unordered_map<std::string, std::string>;


class config_parser final
{
public:
	config_parser() = delete;
	explicit config_parser(std::istream& in) : in_(in) {}

	[[nodiscard]] std::pair<std::vector<std::string>, logging_config_t> parse() const
	{
		std::vector<std::string> config_settings{};
		size_t setting_number{ 0 };
		auto no_logging{ false };

		for (std::string line; std::getline(in_.ignore(std::numeric_limits<std::streamsize>::max(), '='), line); ) {
			if (setting_number == 3 && (line == "false" || line.empty())) {
				no_logging = true;
				break;
			}
			config_settings.emplace_back(line);
			++setting_number;
		}

		if (setting_number < 2) {
			return std::make_pair(std::vector<std::string>{}, logging_config_t{});
		}

		if (no_logging) {
			return std::make_pair(config_settings, logging_config_t{});
		}

		//TODO: handle deducing no type, what to do if type = nothing

		std::vector<std::string> main_settings{ config_settings.begin(), config_settings.begin() + 3 };
		logging_config_t log_settings = { {"type", config_settings.at(4) }, {"color", config_settings.at(5)}, {"filename", config_settings.at(6) } };
		return std::make_pair(main_settings, log_settings);

	}
private:
	std::istream& in_;
};
