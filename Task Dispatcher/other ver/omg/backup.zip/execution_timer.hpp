#pragma once
#include "iostream"
#include <chrono>


class timer
{
public:
	timer() : start_(std::chrono::high_resolution_clock::now()) {}

	auto time() {
		current_ = std::chrono::high_resolution_clock::now();
		const std::chrono::duration<float> duration = current_ - start_;
		return duration.count();
	}
	~timer() {
		//time();
	}

private:
	std::chrono::time_point<std::chrono::steady_clock> start_, current_;
};