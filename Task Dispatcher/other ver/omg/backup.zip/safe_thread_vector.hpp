#pragma once
#include <vector>
#include <mutex>
#include <functional>

template<class T>
using task = std::function<T()>;


template<class T>
class safe_thread_vector {

    
public:
    safe_thread_vector() = default;
    safe_thread_vector(const safe_thread_vector& orig) : std_vector_(orig.std_vector_) {}
    safe_thread_vector(safe_thread_vector&& orig) noexcept : std_vector_{ std::move(orig.std_vector_) } {}
    explicit safe_thread_vector(std::vector<task<T>> vec) : std_vector_{ std::move(vec) } {}

    void emplace_back(task<T> in) {
        std::unique_lock<std::mutex> lock(deque_lock_);
        std_vector_.emplace_back(std::move(in));
    }
    size_t size() const {
        std::unique_lock<std::mutex> lock(deque_lock_);
        return std_vector_.size();
    }
    [[nodiscard]] const std::vector<task<T>>& get_std_vector() const {
        return std_vector_;
    }

private:
    std::vector<task<T>> std_vector_{};
    mutable std::mutex deque_lock_{};
};
