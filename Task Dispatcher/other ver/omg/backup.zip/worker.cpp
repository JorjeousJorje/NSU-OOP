#include "task_dispather.hpp"

void worker::add_task(task_info&& task)
{
	/*std::unique_lock<std::mutex> lock{ task_lock_ };
	const auto was_empty = workers_tasks_.empty();
	
	workers_tasks_.push_back(std::move(task));
	if (was_empty) {
		std::lock_guard wait_lock(wait_lock_);
		waiter_.notify_one();
	}*/

	/*std::unique_lock<std::mutex> lock{ task_lock_ };
	workers_tasks_.push_back(std::move(task));
	waiter_.notify_one();*/
	std::unique_lock<std::mutex> lock{ task_lock_ };
	task_ = std::move(task);
	doing_task_ = true;
	waiter_.notify_one();
}

void worker::thread_stop()
{
	thread_stop_.store(true, std::memory_order_relaxed);
	//std::unique_lock<std::mutex> lock(wait_lock_);
	std::unique_lock<std::mutex> lock(task_lock_);
	waiter_.notify_one();
}

void worker::start()
{
	std::thread thr_(&worker::run, this);
	std::swap(myself_, thr_);
}

worker::~worker()
{
	thread_stop();
	if (myself_.joinable()) {
		myself_.join();
	}
}


void worker::run()
{
	task_info task;
	//bool task_observed = false;
	while (!thread_stop_.load(std::memory_order_relaxed)) {
		/*bool found_task = false;
		std::unique_lock<std::mutex> lock{ task_lock_ };
		
		if (!workers_tasks_.empty()) {
			task = std::move(workers_tasks_.front());
			workers_tasks_.pop_front();
			found_task = true;
			task_observed = true;
		}
		if (!found_task) {
			if (task_observed) {
				lock.unlock();
				std::this_thread::yield();
				continue;
			}
			std::unique_lock<std::mutex> wait_lock(wait_lock_);
			lock.unlock();
			task = task_info{};
			waiter_.wait(wait_lock);
			task_observed = false;
			continue;
		}

		lock.unlock();
		task.task();

		lock.lock();
		const auto ask_for_next = workers_tasks_.empty();
		lock.unlock();
		dispatcher_.task_finished(id_, ask_for_next);*/
		
		/*auto task_found = false;
		std::unique_lock<std::mutex> lock{ task_lock_ };

		if(!workers_tasks_.empty()) {
			task = std::move(workers_tasks_.front());
			workers_tasks_.pop_front();
			task_found = true;
		}

		lock.unlock();

		if(task_found) {
			task.task();
		}

		lock.lock();
		const auto was_empty = workers_tasks_.empty();
		lock.unlock();

		dispatcher_.task_finished(id_, true);
		
		if(was_empty) {
			
			lock.lock();
			if(workers_tasks_.empty()) {
				waiter_.wait(lock);
			}
		}*/
		{
			std::unique_lock<std::mutex> lock{ task_lock_ };
			waiter_.wait(lock, [=] {return doing_task_; });
			task = std::move(task_);
			task_ = {};
		}
		task.task();
		
		std::unique_lock<std::mutex> lock{ task_lock_ };
		doing_task_ = false;
		lock.unlock();
		
		dispatcher_.task_finished(id_);
	}
}
